import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ViewModel()
    
    var body: some View {
        NavigationStack {
            ZStack {
            VStack{
                Image("grifinoria")
                    .resizable()
                    .ignoresSafeArea()
                    .frame(width:400 ,height: 220)
                
                    ScrollView{
                     
                        ForEach(viewModel.chars) { char in
                            NavigationLink(destination: descricao(recebe: char)){
                                HStack {
                                    AsyncImage(url: URL(string: char.image!)) { 
                                        image in image
                                            .resizable()
                                            .frame(width: 100, height: 100)
                                            .clipShape(Circle())
                                    } placeholder: {
                                        ProgressView()
                                    }
                                    
                                    Text(char.name!)
                                        .font(.title)
                                        .foregroundColor(.white)
                                    Spacer()
                                    
                                    
                                }}
                                                     
                        }
                       .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                    }
//
                }
                .background(.rednew)
            }
        }
//
//        .edgesIgnoringSafeArea(.all)
        .onAppear {
            viewModel.fetch()
        }
    }
    
}
#Preview {
    ContentView()
}

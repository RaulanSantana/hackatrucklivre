//
//  harryApp.swift
//  harry
//
//  Created by Turma01-24 on 09/05/24.
//

import SwiftUI

@main
struct harryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

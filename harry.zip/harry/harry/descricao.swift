//
//  descricao.swift
//  harry
//
//  Created by Turma01-24 on 10/05/24.
//

import SwiftUI

struct descricao: View {
    var recebe: HaPo
    var body: some View {
       
        ZStack{
            Color(.rednew)
                .ignoresSafeArea()
            VStack{
                AsyncImage(url: URL(string: recebe.image!)) {
                    image in image
                        .resizable()
                        .frame(width: 300, height: 300)
                    
                } placeholder: {
                    ProgressView()
                }
                
                Text(recebe.name!)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.white)
                VStack {
                    
                    Text("Especie: \(recebe.species!)")
                    Text("House: \(recebe.house!)")
                    Text("Gender: \(recebe.gender!)")
                    Text("Date of birth: \(recebe.dateOfBirth!)")
                    Text("Wizard: \(String(recebe.wizard!))")
                    Text("Ancestry: \(recebe.ancestry!)")
                    
                    
                }
                .foregroundColor(.white)
                Spacer()
                
               
                
            }
            
        }
      
      
        
    }
       
}


